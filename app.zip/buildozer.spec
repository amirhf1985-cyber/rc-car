[app]

title = BLE RC Car
package.name = rc_car
package.domain = org.example

source.dir = .
source.include_exts = py,png,jpg,jpeg,ttf,wav,mp3,json,txt,kv
source.include_patterns = assets/**

version = 1.0.0
version.code = 5

requirements = python3,kivy==2.3.0,plyer,pyjnius,setuptools

icon.filename = assets/icon.png
presplash.filename = assets/presplash.jpg

orientation = landscape
fullscreen = 1

android.wakelock = True
android.pause_min_size = 1

# Permissions
android.permissions = BLUETOOTH,BLUETOOTH_ADMIN,ACCESS_FINE_LOCATION,ACCESS_COARSE_LOCATION,BLUETOOTH_SCAN,BLUETOOTH_CONNECT,VIBRATE,POST_NOTIFICATIONS,FOREGROUND_SERVICE

# Android settings
android.api = 33
android.target_sdk_version = 33
android.minapi = 24

android.ndk = 25c
android.archs = arm64-v8a

android.activity_launch_mode = singleTask
android.disable_screen_off = True

android.accept_sdk_license = True
android.enable_androidx = True

[buildozer]

log_level = 2
warn_on_root = 1